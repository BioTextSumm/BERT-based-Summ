'''
@author: Milad Moradi
'''

import json
import json_lines
import nltk
import random
import math

#--------------------
class Feature:
    
    def __init__(self, word):
        self.token = word
        self.weight_list = []

class Sentence:
    
    def __init__(self, num, txt):
        self.sentence_number = num
        self.sentence_text = txt
        self.avg_distance = 0
        self.feature_list = []
        self.representation = []
        self.cluster_index = 0
        
    def eucl_distance(self, second_vector):
        eucl_dist = 0
        i = 0
        for weight in self.representation:
            eucl_dist += (weight - second_vector[i]) ** 2
            i += 1
        
        eucl_dist = math.sqrt(eucl_dist)
        return eucl_dist;
    
    def cosine_similarity(self, second_vector):
        numerator = 0
        term1 = 0
        term2 = 0
        i = 0
        for weight in self.representation:
            numerator += weight * second_vector[i]
            term1 += weight ** 2
            term2 += second_vector[i] ** 2
            i += 1
            
        denominator = math.sqrt(term1) * math.sqrt(term2)
        cosine_sim = numerator / denominator
        return cosine_sim
    
    
    def set_token_list(self, tkn_list):
        self.feature_list = tkn_list
    
    def get_token_list(self):
        return self.feature_list;

class Cluster:
    
    def __init__(self, num):
        self.cluster_number = num
        self.mean = []
        self.members = []
        self.summary_members = 0
        
    def add_member(self, sentence_index):
        self.members.append(sentence_index)
        
    def remove_member(self, sentence_index):
        self.members.remove(sentence_index)
#--------------------

def produce_summary(compression_rate, sentence_list, clusters, output_address):
    
    summary_size = math.ceil(len(sentence_list) * compression_rate) + 1
    print('\nSummary size: ', summary_size)

    i = 0
    for cluster in clusters:
        cluster.summary_members = round(summary_size * (len(cluster.members) / len(sentence_list)))
        print('Cluster index: ', i, ', Cluster size: ', len(cluster.members),  ', Summary members: ', cluster.summary_members)
        i += 1
    
    #--------------------- Sentence selection
 
    for cluster in clusters:
        for sentence_index in cluster.members:
            temp_avg_distance = 0
            denominator = 0
        
            for other_member in cluster.members:
                if sentence_index != other_member:
                    temp_avg_distance += sentence_list[sentence_index].eucl_distance(sentence_list[other_member].representation)
                    denominator += 1
                
            if denominator != 0:
                temp_avg_distance /= denominator
            sentence_list[sentence_index].avg_distance = temp_avg_distance
        
    #------------------------------------------------------------------------------------------------
    print('---------- Before Sorting --------')
    i = 0
    for cluster in clusters:
        print('Cluster index: ', i)
        for index in cluster.members:
            print('Sentence index: ', index, ', Avg distance: ', sentence_list[index].avg_distance)
        i += 1
    #------------------------------------------------------------------------------------------------


    #Sort members of each cluster
    for cluster in clusters:
        #-----------------Bubble sort
        for i in range(0, len(cluster.members)):
            for j in range(i+1, len(cluster.members)):
                if sentence_list[cluster.members[i]].avg_distance > sentence_list[cluster.members[j]].avg_distance:
                    temp_index = cluster.members[i]
                    cluster.members[i] = cluster.members[j]
                    cluster.members[j] = temp_index
                
    #------------------------------------------------------------------------------------------------
    print('---------- After Sorting --------')
    i = 0
    for cluster in clusters:
        print('Cluster index: ', i)
        for index in cluster.members:
            print('Sentence index: ', index, ', Avg distance: ', sentence_list[index].avg_distance)
        i += 1
    #------------------------------------------------------------------------------------------------

    summary_index=[]
    for cluster in clusters:
        for i in range(0, cluster.summary_members):
            summary_index.append(cluster.members[i])
        
    print('---------- Selected sentences --------')
    for index in summary_index:
        print(index)
    
    summary_index.sort()
    print('---------- Sorted selected sentences --------')
    for index in summary_index:
        print(index)

    #----------------------- Producing final summary
    final_summary = ''
    i = 0
    for index in summary_index:
        print(sentence_list[index].sentence_text)
        if i > 0:
            final_summary += ' '
        final_summary += sentence_list[index].sentence_text
        i += 1
    print(' ')
    print(final_summary)

    final_output = '<html>'
    final_output += '\n<head>'
    final_output += '\n</head>'
    final_output += '\n<body bgcolor="white">'
    final_output += '\n<a name="1">[1]</a> <a href="#1" id=1>'
    final_output += final_summary
    final_output += '\n</a>'
    final_output += '\n</body>'
    final_output += '\n</html>'

    output_file_text = open(output_address, 'w')
    output_file_text.write(final_output)
    output_file_text.close()
    
    return



#--------------------------------------------------------------------------------------------------------------------------------------------------------------

#-------------------- Main body of summarizer --------------------

compression_rate = 0.3

for number_of_clusters in range(2, 13):
    
    for run in range(1, 2):
        for document_number in range(1, 301):
            print('---------- Text summarizer started for document: ' + str(document_number) + ' ----------\n')
    
            input_address_text = 'Dataset-Preprocessed-Text\\' + str(document_number) + '.txt'
            input_address_feature = 'Dataset-Preprocessed-Feature-BERT Large\\' + str(document_number) + '.jsonl'
            output_address = 'Summary-BERT Large\\Run' + str(run) + '-V8-C' + str(number_of_clusters) + '-' + str(document_number) + '.html'


            input_file = open(input_address_text)
            print("-----File opened-----")

            input_text = input_file.read()
            print("-----File read-----")

            input_sentences = nltk.sent_tokenize(input_text)

            sentence_list = []
            sentence_num = 0

            for sentence in input_sentences:
                sentence_num += 1
                temp_sentence = Sentence(sentence_num, sentence)
                sentence_list.append(temp_sentence)
    
            for sentence in sentence_list:
                print("\n----- Sentence number: ", sentence.sentence_number)
                print(sentence.sentence_text)
                print(sentence.feature_list)

            #--------------------

            sentence_num = 0
            with open(input_address_feature) as input_file:
                for line in json_lines.reader(input_file):
                    print('Line: ', line['linex_index'])
                    feature_set = line['features']
        
                    for feature in feature_set:
                        if feature['token'] in ['[CLS]', '[SEP]']:
                            continue;
            
                        temp_feature = Feature(feature['token'])
            
                        print("'", feature['token'], "'")
            
                        for layer in feature['layers']:
                            temp_feature.weight_list = layer['values']
                            print(len(layer['values']))
                        sentence_list[sentence_num].feature_list.append(temp_feature)
                    sentence_num += 1
    
    
            for sentence in sentence_list:
                print("\n----- Sentence number: ", sentence.sentence_number)
                print(sentence.sentence_text)
    
                for feature in sentence.feature_list:
                    print(feature.token)   
                    print(feature.weight_list[0])
        
            print('-----------------------------------------------')

            i=0
            for weight in sentence_list[0].feature_list[0].weight_list:
                i+=1
                print('Weight ', i, ': ', weight)
            print('\nI = ', i)

            #-------------------- Compute a representation for every sentence

            for sentence in sentence_list:
                for weight in sentence.feature_list[0].weight_list:
                    sentence.representation.append(0.0)
        
                for feature in sentence.feature_list:
                    i = 0
                    for weight in feature.weight_list:
                        sentence.representation[i] += weight
                        i += 1
            
                j = 0
                for weight in sentence.representation:
                    sentence.representation[j] /= len(sentence.feature_list)
                    j += 1


        
        
            #-------------------- Clustering algorithm
            print('\n---------- Clustering started ----------')

            clusters = []

        
            i = 0
            for sentence in sentence_list:
                temp_cluster = Cluster(i+1)
                temp_cluster.members.append(i)
                clusters.append(temp_cluster)
                i += 1
    
            for cluster in clusters:
                print('Cluster number: ', cluster.cluster_number, ', Members: ', cluster.members )
        
    

            #Starting clustering algorithm
            max_number_of_clusters = number_of_clusters
            min_number_of_clusters = 2
            
            end_of_clustering = False

            iteration = 1
            while (end_of_clustering != True):
    
                print('---------- Iteration: ', iteration)
                
                nearest_distance = 10000000000
                nearest_cluster1 = -1
                nearest_cluster2 = -1
                
                for i in range(0, len(clusters)):
                    for j in range(0, len(clusters)):
                        
                        if i < j:
                            
                            #----------Compute the distance between two clusters
                            denominator = 0
                            temp_distance = 0
                            for index1 in clusters[i].members:
                                for index2 in clusters[j].members:
                                    
                                    temp_distance += sentence_list[index1].eucl_distance(sentence_list[index2].representation)
                                    denominator += 1
                                    
                            if denominator != 0:
                                temp_distance /= denominator
                            
                            if temp_distance < nearest_distance:
                                nearest_distance = temp_distance
                                nearest_cluster1 = i
                                nearest_cluster2 = j
                            
                #----------Merge two nearest clusters
                clusters[nearest_cluster1].members = clusters[nearest_cluster1].members + clusters[nearest_cluster2].members
                clusters.remove(clusters[nearest_cluster2])
                print(nearest_cluster1, 'and', nearest_cluster2, 'merged')
                
                print('Number of clusters: ', str(len(clusters)))
                
                iteration += 1
                if len(clusters) <= min_number_of_clusters:
                    end_of_clustering = True
                    
                if len(clusters) <= max_number_of_clusters and len(clusters) >= min_number_of_clusters:
                    output_address = 'Summary-BERT Large\\Run' + str(run) + '-V8-C' + str(len(clusters)) + '-' + str(document_number) + '.html'
                    produce_summary(compression_rate, sentence_list, clusters, output_address)
                    
                #-------------------- End of clustering algorithm

            print('\n---------- Summarization ended for document: ' + str(document_number) + '----------\n')